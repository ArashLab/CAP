This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.70-5bb98953a4a7
  Created at 2021/07/06 12:04:55